import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  login_api = "https://xebiascart.herokuapp.com/users?username=amigo";

  constructor(private http:HttpClient) { }

  getLoginDetails(){
    return this.http.get(this.login_api);
  }
}
