import { Component, OnInit, Input } from '@angular/core';
import { FiltersComponent } from '../filters/filters.component';
import { FilterService } from 'src/app/services/filter.service';

@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css']
})
export class BrandComponent implements OnInit {

  @Input('brand') brand;
  bandcheckedList=[]
  constructor(private filterService:FilterService) { }

  ngOnInit(): void {
  
  }
  brandChange(event,ban) {
    // console.log(this.filterColor);
     if(event.target.checked) {
       this.bandcheckedList.push(ban.title);
     } else {
     for(var i=0 ; i < this.brand.length; i++) {
       if(this.bandcheckedList[i] == ban.title) {
         this.bandcheckedList.splice(i,1);
      }
    }
  }
  

   this.filterService.selectedBand.next(this.bandcheckedList);

 
 }
   
}
